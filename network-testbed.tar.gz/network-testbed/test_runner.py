"""
test_runner.py
Orchestrates connectivity test suites:
  - baseline (pre-failure)
  - post_failure
  - recovery (post-restore)
Calls network_manager ping + subprocess docker exec for checks.
"""

import subprocess
import time
from typing import Optional

import yaml

from network_manager import NetworkManager
from utils.logger import get_logger

logger = get_logger("test_runner")


class TestCase:
    def __init__(self, name: str, src: str, dst_ip: str, expected_reachable: bool = True):
        self.name = name
        self.src = src
        self.dst_ip = dst_ip
        self.expected_reachable = expected_reachable
        self.result: Optional[bool] = None
        self.packet_loss: Optional[float] = None
        self.avg_rtt: Optional[float] = None
        self.raw_output: str = ""


class TestRunner:
    def __init__(self, config_path: str = "config.yaml"):
        with open(config_path) as f:
            self.cfg = yaml.safe_load(f)
        self.nm = NetworkManager(config_path)
        self.ping_count = self.cfg.get("testing", {}).get("ping_count", 4)

    # ── Test Suites ──────────────────────────────────────────

    def run_baseline(self) -> dict:
        """Full connectivity matrix: intra-leaf + cross-leaf L3 reachability."""
        logger.info("=== BASELINE CONNECTIVITY TESTS ===")
        cases = self._build_test_cases(expect_all_pass=True)
        return self._execute_suite("baseline", cases)

    def run_post_failure(self) -> dict:
        """Post-failure: some tests expected to fail."""
        logger.info("=== POST-FAILURE CONNECTIVITY TESTS ===")
        cases = self._build_test_cases(expect_all_pass=False)
        return self._execute_suite("post_failure", cases)

    def run_recovery(self) -> dict:
        """Post-restore: all tests expected to pass again."""
        logger.info("=== RECOVERY CONNECTIVITY TESTS ===")
        cases = self._build_test_cases(expect_all_pass=True)
        return self._execute_suite("recovery", cases)

    # ── Test Case Builder ────────────────────────────────────

    def _build_test_cases(self, expect_all_pass: bool = True) -> list[TestCase]:
        cases = []

        hosts = self.cfg["topology"]["hosts"]
        host_map = {h["name"]: h for h in hosts}

        # L2 same-leaf tests (host1 <-> host2, both on leaf1)
        same_leaf_pairs = [
            ("host1", "host2"),  # leaf1
            ("host3", "host4"),  # leaf2
            ("host5", "host6"),  # leaf3
            ("host7", "host8"),  # leaf4
        ]
        for src_name, dst_name in same_leaf_pairs:
            dst_ip = host_map[dst_name]["ip"].split("/")[0]
            cases.append(TestCase(
                name=f"L2_{src_name}->{dst_name}",
                src=src_name,
                dst_ip=dst_ip,
                expected_reachable=expect_all_pass,
            ))

        # L3 cross-leaf tests (representative)
        cross_leaf_pairs = [
            ("host1", "host3"),  # leaf1 -> leaf2
            ("host1", "host5"),  # leaf1 -> leaf3
            ("host1", "host7"),  # leaf1 -> leaf4
            ("host3", "host5"),  # leaf2 -> leaf3
            ("host5", "host7"),  # leaf3 -> leaf4
        ]
        for src_name, dst_name in cross_leaf_pairs:
            dst_ip = host_map[dst_name]["ip"].split("/")[0]
            cases.append(TestCase(
                name=f"L3_{src_name}->{dst_name}",
                src=src_name,
                dst_ip=dst_ip,
                expected_reachable=expect_all_pass,
            ))

        # Host-to-leaf-gateway tests
        leaf_cfg = {l["name"]: l for l in self.cfg["topology"]["leaves"]}
        for host in hosts:
            leaf_name = host["leaf"]
            gw_ip = host["gateway"]
            cases.append(TestCase(
                name=f"GW_{host['name']}->{leaf_name}",
                src=host["name"],
                dst_ip=gw_ip,
                expected_reachable=expect_all_pass,
            ))

        # Spine reachability from leaf1
        for spine in self.cfg["topology"]["spines"]:
            spine_mgmt = spine["management_ip"]
            cases.append(TestCase(
                name=f"SPINE_leaf1->{spine['name']}",
                src="host1",
                dst_ip=spine_mgmt,
                expected_reachable=expect_all_pass,
            ))

        return cases

    # ── Execution Engine ─────────────────────────────────────

    def _execute_suite(self, suite_name: str, cases: list[TestCase]) -> dict:
        passed = 0
        failed = 0
        results = []

        for tc in cases:
            ping_result = self.nm.ping(tc.src, tc.dst_ip, count=self.ping_count)
            tc.packet_loss = ping_result["packet_loss_pct"]
            tc.avg_rtt = ping_result["avg_rtt_ms"]
            tc.raw_output = ping_result["raw"]

            # Determine pass/fail
            reachable = ping_result["success"] and (ping_result["packet_loss_pct"] or 100) < 100
            if tc.expected_reachable:
                tc.result = reachable
            else:
                # In post-failure we just record observed state
                tc.result = True  # not a failure of the test itself

            status = "PASS" if tc.result else "FAIL"
            loss_str = f"{tc.packet_loss:.0f}%" if tc.packet_loss is not None else "n/a"
            rtt_str = f"{tc.avg_rtt:.1f}ms" if tc.avg_rtt is not None else "n/a"

            logger.info(
                f"  [{status}] {tc.name:40s} loss={loss_str:6s} rtt={rtt_str}"
            )

            if tc.result:
                passed += 1
            else:
                failed += 1

            results.append({
                "name": tc.name,
                "src": tc.src,
                "dst_ip": tc.dst_ip,
                "status": status,
                "packet_loss_pct": tc.packet_loss,
                "avg_rtt_ms": tc.avg_rtt,
                "expected_reachable": tc.expected_reachable,
            })

        logger.info(f"  Suite '{suite_name}': {passed} passed / {failed} failed")
        return {
            "suite": suite_name,
            "passed": passed,
            "failed": failed,
            "total": passed + failed,
            "cases": results,
        }
